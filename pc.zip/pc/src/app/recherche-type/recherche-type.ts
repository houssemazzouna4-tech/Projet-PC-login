import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PC } from '../model/pc.model';
import { TypePc } from '../model/type.model';
import { PcService } from '../services/pc';

@Component({
  selector: 'app-recherche-type',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './recherche-type.html',
  styleUrl: './recherche-type.css'
})
export class RechercheParType implements OnInit {
  pcs: PC[] = [];
  pcsFiltres: PC[] = [];
  types: TypePc[] = [];
  typeSelectionne: number | null = null;

  constructor(private pcService: PcService) {}

  ngOnInit(): void {
    this.pcs = this.pcService.listePcs();
    this.pcsFiltres = this.pcs;
    this.types = this.pcService.listeTypes();
  }

  rechercherParType(): void {
    if (this.typeSelectionne === null) {
      this.pcsFiltres = this.pcs;
    } else {
      this.pcsFiltres = this.pcs.filter(
        pc => pc.typePc.idType === this.typeSelectionne
      );
    }
  }
}
