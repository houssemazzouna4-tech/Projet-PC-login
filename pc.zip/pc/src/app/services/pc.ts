import { Injectable } from '@angular/core';
import { PC } from '../model/pc.model';
import { TypePc } from '../model/type.model';

@Injectable({
  providedIn: 'root'
})
export class PcService {
  types: TypePc[] = [
    { idType: 1, nomType: 'Desktop' },
    { idType: 2, nomType: 'Laptop' }
  ];

  pcs: PC[] = [
    {
      idPc: 1,
      nomPc: 'PC Asus',
      prixPc: 3000.6,
      dateCreation: new Date('01/14/2011'),
      typePc: { idType: 2, nomType: 'Laptop' }
    },
    {
      idPc: 2,
      nomPc: 'PC HP',
      prixPc: 2500,
      dateCreation: new Date('12/17/2010'),
      typePc: { idType: 1, nomType: 'Desktop' }
    },
    {
      idPc: 3,
      nomPc: 'PC Lenovo',
      prixPc: 2800.123,
      dateCreation: new Date('02/20/2020'),
      typePc: { idType: 2, nomType: 'Laptop' }
    }
  ];

  listePcs(): PC[] {
    return this.pcs;
  }

  listeTypes(): TypePc[] {
    return this.types;
  }

  consulterType(id: number): TypePc {
    return this.types.find(t => t.idType == id)!;
  }

  ajouterPc(pc: PC): void {
    this.pcs.push(pc);
  }

  modifierPc(pc: PC): void {
    const index = this.pcs.findIndex(p => p.idPc === pc.idPc);

    if (index !== -1) {
      this.pcs[index] = { ...pc };
    }
  }

  supprimerPc(pc: PC ): void {
    this.pcs = this.pcs.filter(p => p.idPc !== pc.idPc);
  }
}