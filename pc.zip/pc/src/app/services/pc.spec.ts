import { Injectable } from '@angular/core';
import { PC } from '../model/pc.model';

@Injectable({ providedIn: 'root' })
export class PcService {
  pcs: PC[] = [
    { idPC: 1, nomPC: 'PC Asus', prixPC: 3000.6, dateCreation: new Date('2011-01-14'), type: 'Laptop' },
    { idPC: 2, nomPC: 'PC HP', prixPC: 2500, dateCreation: new Date('2010-12-17'), type: 'Desktop' },
    { idPC: 3, nomPC: 'PC Lenovo', prixPC: 2800.123, dateCreation: new Date('2020-02-20'), type: 'Laptop' },
  ];

  types: string[] = ['Desktop', 'Laptop'];

  listePCs(): PC[] {
    return this.pcs;
  }

  ajouterPC(pc: PC): void {
    this.pcs.push(pc);
  }

  supprimerPC(pc: PC): void {
    const index = this.pcs.indexOf(pc);
    if (index > -1) {
      this.pcs.splice(index, 1);
    }
  }

  consulterPC(id: number): PC | undefined {
    return this.pcs.find((p) => p.idPC === id);
  }

  updatePC(pc: PC): void {
    const index = this.pcs.findIndex((p) => p.idPC === pc.idPC);
    if (index > -1) {
      this.pcs[index] = pc;
    }
  }

  rechercherParType(type: string): PC[] {
    return this.pcs.filter((p) => p.type === type);
  }
}