import { TypePc } from './type.model';

export class PC {
  idPc!: number;
  nomPc!: string;
  prixPc!: number;
  dateCreation!: Date;
  typePc!: TypePc;
}