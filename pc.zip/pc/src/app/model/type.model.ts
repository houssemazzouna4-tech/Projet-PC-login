export class TypePc {
  idType!: number;
  nomType!: string;
}