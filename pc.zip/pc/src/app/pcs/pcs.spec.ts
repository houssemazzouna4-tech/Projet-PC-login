import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Pcs } from './pcs';

describe('Pcs', () => {
  let component: Pcs;
  let fixture: ComponentFixture<Pcs>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Pcs]
    }).compileComponents();

    fixture = TestBed.createComponent(Pcs);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});