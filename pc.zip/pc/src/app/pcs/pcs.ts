
import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { PC } from '../model/pc.model';
import { PcService } from '../services/pc';
import { AuthService } from '../services/auth';

@Component({
  selector: 'app-pcs',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './pcs.html',
  styleUrl: './pcs.css'
})
export class Pcs {

  auth = inject(AuthService);
  pcs: PC[];

  constructor(private pcService: PcService) {
    this.pcs = this.pcService.listePcs();
  }

  supprimer(pc: PC): void {
    if (this.auth.isAdmin()) {
      if (confirm('Voulez-vous vraiment supprimer ce PC ?')) {
        this.pcService.supprimerPc(pc);
        this.pcs = this.pcService.listePcs();
      }
    }
  }
}
