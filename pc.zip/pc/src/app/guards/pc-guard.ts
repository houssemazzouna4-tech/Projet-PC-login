import { CanActivateFn } from '@angular/router';

export const pcGuard: CanActivateFn = (route, state) => {
  return true;
};
