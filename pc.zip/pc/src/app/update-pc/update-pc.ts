import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { PC } from '../model/pc.model';
import { TypePc } from '../model/type.model';
import { PcService } from '../services/pc';

@Component({
  selector: 'app-update-pc',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './update-pc.html',
  styleUrl: './update-pc.css'
})
export class UpdatePc implements OnInit {
  pcSelectionne!: PC;
  types!: TypePc[];
  updatedTypeId!: number;
  dateModification = '';

  constructor(
    private pcService: PcService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.types = this.pcService.listeTypes();

    const id = Number(this.route.snapshot.paramMap.get('id'));
    const pc = this.pcService.listePcs().find(p => p.idPc === id);

    if (pc) {
      this.pcSelectionne = { ...pc };

      this.updatedTypeId =
        this.pcSelectionne.typePc?.idType ?? 1;

      if (this.pcSelectionne.dateCreation) {
        const date = new Date(this.pcSelectionne.dateCreation);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');

        this.dateModification = `${year}-${month}-${day}`;
      }
    } else {
      this.router.navigate(['/pcs']);
    }
  }

  enregistrerModification(): void {
    if (this.pcSelectionne) {
      this.pcSelectionne.typePc =
        this.pcService.consulterType(this.updatedTypeId);

      this.pcSelectionne.dateCreation =
        new Date(this.dateModification + 'T12:00:00');

      this.pcService.modifierPc(this.pcSelectionne);

      this.router.navigate(['/pcs']);
    }
  }
}