import { Pipe, PipeTransform } from '@angular/core';
import { PC } from './model/pc.model';

@Pipe({
  name: 'searchFilter',
  standalone: true
})
export class SearchFilterPipe implements PipeTransform {
  transform(pcs: PC[], searchTerm: string): PC[] {
    if (!pcs) {
      return [];
    }

    if (!searchTerm || searchTerm.trim() === '') {
      return pcs;
    }

    return pcs.filter(pc =>
      pc.nomPc.toLowerCase().includes(searchTerm.trim().toLowerCase())
    );
  }
}
