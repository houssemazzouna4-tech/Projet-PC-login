
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PC } from '../model/pc.model';
import { PcService } from '../services/pc';
import { SearchFilterPipe } from '../search-filter-pipe';

@Component({
  selector: 'app-recherche-pipe',
  standalone: true,
  imports: [CommonModule, FormsModule, SearchFilterPipe],
  templateUrl: './recherche-pipe.html',
  styleUrl: './recherche-pipe.css'
})
export class RecherchePipe implements OnInit {
  pcs: PC[] = [];
  searchTerm = '';

  constructor(private pcService: PcService) {}

  ngOnInit(): void {
    this.pcs = this.pcService.listePcs();
  }
}
