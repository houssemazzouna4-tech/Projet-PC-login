import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PC } from '../model/pc.model';
import { PcService } from '../services/pc';

@Component({
  selector: 'app-recherche-keyup',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './recherche-keyup.html',
  styleUrl: './recherche-keyup.css'
})
export class RechercheParNomKeyup implements OnInit {
  pcs: PC[] = [];
  pcsFiltres: PC[] = [];

  constructor(private pcService: PcService) {}

  ngOnInit(): void {
    this.pcs = this.pcService.listePcs();
    this.pcsFiltres = this.pcs;
  }

  rechercherParNom(event: Event): void {
    const nom = (event.target as HTMLInputElement).value.toLowerCase();

    this.pcsFiltres = this.pcs.filter(
      pc => pc.nomPc.toLowerCase().includes(nom)
    );
  }
}