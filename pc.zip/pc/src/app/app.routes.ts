import { Routes } from '@angular/router';
import { Pcs } from './pcs/pcs';
import { AddPc } from './add-pc/add-pc';
import { UpdatePc } from './update-pc/update-pc';
import { RechercheParType } from './recherche-type/recherche-type';
import { RechercheParNomKeyup } from './recherche-keyup/recherche-keyup';
import { RecherchePipe } from './recherche-pipe/recherche-pipe';
import { Login } from './login/login';
import { Forbidden } from './forbidden/forbidden';
import { pcGuard } from './guards/pc-guard';

export const routes: Routes = [
  { path: '', redirectTo: 'pcs', pathMatch: 'full' },
  { path: 'pcs', component: Pcs },
  { path: 'add-pc', component: AddPc, canActivate: [pcGuard] },
  { path: 'updatePc/:id', component: UpdatePc, canActivate: [pcGuard] },
  { path: 'rechercheParCategorie', component: RechercheParType },
  { path: 'rechercheParNomKeyup', component: RechercheParNomKeyup },
  { path: 'rechercheParNomPipe', component: RecherchePipe },
  { path: 'login', component: Login },
  { path: 'app-forbidden', component: Forbidden },
];